import {
  ladeMandantendaten,
  ladeAnalytendaten,
  verarbeiteDaten,
} from "./daten.js";
import {
  initialisiereLaderad,
  deaktiviereLaderad,
  initialisiereMandantenspezifischeAnzeige,
  initialisiereMenuebutton,
  initialisiereSuche,
  initialisiereZeichenraster,
  initialisiereWerkzeugbox,
  initialisiereDynamischeSeitenhoehe,
  beobachteHashAenderung,
  initialisiereNachObenButton,
  initialisiereFooter,
} from "./anzeige.js";

document.addEventListener("DOMContentLoaded", async () => {
  try {
    initialisiereLaderad();
    await ladeMandantendaten();
    initialisiereMandantenspezifischeAnzeige();
    verarbeiteDaten(await ladeAnalytendaten());
    initialisiereMenuebutton();
    initialisiereSuche();
    initialisiereZeichenraster();
    initialisiereWerkzeugbox();
    initialisiereDynamischeSeitenhoehe();
    beobachteHashAenderung();
    initialisiereNachObenButton();
    initialisiereFooter();
  } catch (fehler) {
    document.getElementById(
      "ergebnisbox"
    ).innerHTML = `<div id="ergebnisse" class="active"><h2>Fehler beim Verarbeiten der Daten.</h2></div>`;
  } finally {
    deaktiviereLaderad();
  }
});
