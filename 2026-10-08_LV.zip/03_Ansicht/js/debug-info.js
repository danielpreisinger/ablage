// ==== Debug Modal Dialog ====
// TODO: Temporären Code entfernen, bevor Go-Live!
window.zeigeDebugDialog = function (analytCode) {
  // Finde alle Analyten mit diesem CODE
  const alleAnalytenMitCode = globaleAnalytendaten.filter(
    (a) => a.CODE === analytCode
  );

  if (alleAnalytenMitCode.length === 0) return;

  // Nimm den ersten für die Basis-Informationen
  const basisAnalyt = alleAnalytenMitCode[0];

  // Analysiere Felder auf gemeinsame Werte
  const feldNamen = [
    "ANALYTX",
    "KATEGORISIERUNG_CODE",
    "MATERIALNAME",
    "FORMULARCODE",
    "FORMULARNAME",
    "VEKTORX",
    "VEKTOR_SORT",
    "VEKTOR_ANALYTX",
    "VEKTOR_GRANALYTX",
    "VEKTOR_GRSORT",
    "VEKTOR_KENNUNG",
    "VEKTOR_EBENE",
    "METHGRUPPE_ANA_ANALYTX",
    "METHGRUPPE_ANALYTX",
    "METHGRUPPE_SORT",
  ];

  const gemeinsameFelder = new Set();

  // Prüfe für jedes Feld, ob alle Objekte den gleichen Wert haben
  feldNamen.forEach((feldName) => {
    const werte = alleAnalytenMitCode.map((analyt) => analyt[feldName]);
    const ersterWert = werte[0];
    const alleGleich = werte.every((wert) => wert === ersterWert);

    if (alleGleich) {
      gemeinsameFelder.add(feldName);
    }
  });

  // Berechne Normen-Status für alle Analyten
  const normenStatusMap = new Map();
  if (alleAnalytenMitCode.length > 1) {
    alleAnalytenMitCode.forEach((analyt, index) => {
      if (analyt.normen && analyt.normen.length > 0) {
        const alleNormenArrays = alleAnalytenMitCode.map((a) => a.normen || []);
        const normenGleich = vergleicheNormenArrays(alleNormenArrays);
        normenStatusMap.set(index, normenGleich);
      }
    });
  }

  // Bestimme CSS-Klassen für Normen-Spalte analog zu anderen Feldern
  let normenSpaltenKlasse = "feld-spalte";
  let normenZellenKlasse = "normen-spalte-zelle";

  // Prüfe sowohl Vorhandensein als auch Inhalt der Normen
  const normenZustaende = alleAnalytenMitCode.map((analyt) =>
    analyt.normen && analyt.normen.length > 0 ? "hat_normen" : "keine_normen"
  );
  const ersterZustand = normenZustaende[0];
  const alleNormenZustaendeGleich = normenZustaende.every(
    (zustand) => zustand === ersterZustand
  );

  // Zusätzlich prüfen: Wenn alle Objekte Normen haben, sind die Normen auch inhaltlich gleich?
  let normenInhaltGleich = true;
  if (
    alleNormenZustaendeGleich &&
    ersterZustand === "hat_normen" &&
    alleAnalytenMitCode.length > 1
  ) {
    const alleNormenArrays = alleAnalytenMitCode.map(
      (analyt) => analyt.normen || []
    );
    normenInhaltGleich = vergleicheNormenArrays(alleNormenArrays);
  }

  // Spalte ist nur grün wenn SOWOHL Zustand als auch Inhalt gleich sind
  if (alleNormenZustaendeGleich && normenInhaltGleich) {
    normenSpaltenKlasse += " gemeinsames-feld";
    normenZellenKlasse += " gemeinsames-feld";
  } else {
    normenSpaltenKlasse += " divergentes-feld";
    normenZellenKlasse += " divergentes-feld";
  }

  // Erstelle Vergleichstabelle (Achsen getauscht: Spalten = Felder, Zeilen = Objekte)
  const vergleichstabelle = `
    <div class="debug-vergleichstabelle-container">
      <table class="debug-vergleichstabelle">
        <thead>
          <tr>
            <th class="objekt-spalte">Objekt</th>
            ${feldNamen
              .map((feldName) => {
                const istGemeinsam = gemeinsameFelder.has(feldName);
                const cssKlasse = istGemeinsam
                  ? "gemeinsames-feld"
                  : "divergentes-feld";
                return `<th class="feld-spalte ${cssKlasse}">${feldName}</th>`;
              })
              .join("")}
            <th class="${normenSpaltenKlasse}">normen</th>
          </tr>
        </thead>
        <tbody>
          ${alleAnalytenMitCode
            .map((analyt, index) => {
              const normenAnzahl = analyt.normen ? analyt.normen.length : 0;
              let normenToggleKlasse = "normen-toggle"; // Buttons bleiben immer grau

              const hauptZeile = `
            <tr class="analyt-hauptzeile" data-analyt-index="${index}">
              <td class="objekt-info">
                ${index + 1}
              </td>
              ${feldNamen
                .map((feldName) => {
                  const wert = analyt[feldName];
                  const istGemeinsam = gemeinsameFelder.has(feldName);
                  const cssKlasse = istGemeinsam
                    ? "gemeinsames-feld"
                    : "divergentes-feld";
                  return `
                <td class="${cssKlasse}" data-wert="${wert || "-"}" title="${
                    wert || "-"
                  }">
                  <code>${wert ?? "-"}</code>
                </td>
              `;
                })
                .join("")}
              <td class="${normenZellenKlasse}">
                ${
                  normenAnzahl > 0
                    ? `<button class="${normenToggleKlasse}" onclick="toggleNormen(${index})" title="${normenAnzahl} Norm(en) anzeigen/verbergen">📋 ${normenAnzahl}</button>`
                    : "-"
                }
              </td>
            </tr>`;

              const normenZeile =
                normenAnzahl > 0
                  ? `
            <tr class="normen-details-zeile" id="normen-${index}" style="display: none;">
              <td colspan="${feldNamen.length + 2}" class="normen-container">
                <div class="normen-header">
                  📋 Normen (${normenAnzahl})
                </div>
                <div class="normen-tabelle-container">
                  <table class="normen-tabelle">
                    <thead>
                      <tr>
                        <th>Nr.</th>
                        <th>ALTERVON</th>
                        <th>ALTERBIS</th>
                        <th>ZEITEINHEIT</th>
                        <th>GESCHLECHT</th>
                        <th>NORMVON</th>
                        <th>NORMBIS</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${analyt.normen
                        .map(
                          (norm, normIndex) => `
                        <tr class="normen-zeile">
                          <td class="norm-nummer">${normIndex + 1}</td>
                          <td class="norm-wert">${norm.ALTERVON || "-"}</td>
                          <td class="norm-wert">${norm.ALTERBIS || "-"}</td>
                          <td class="norm-wert">${norm.ZEITEINHEIT || "-"}</td>
                          <td class="norm-wert">${norm.GESCHLECHT || "-"}</td>
                          <td class="norm-wert">${norm.NORMVON || "-"}</td>
                          <td class="norm-wert">${norm.NORMBIS || "-"}</td>
                        </tr>
                      `
                        )
                        .join("")}
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>`
                  : "";

              return hauptZeile + normenZeile;
            })
            .join("")}
        </tbody>
      </table>
    </div>
  `;
  const modal = document.createElement("div");
  modal.className = "debug-modal";
  modal.innerHTML = `
    <div class="debug-modal-content">
      <div class="debug-modal-header">
        <div class="debug-header-content">
          <h3>🔧 ${basisAnalyt.BESCHREIBUNG} - <span class="debug-code-chip" data-wert="${analytCode}" title="Klicken zum Kopieren">${analytCode}</span></h3>
          <div class="debug-legende">
            <span class="legende-item">
              <span class="farbe-gemeinsam"></span>
              Gemeinsam
            </span>
            <span class="legende-item">
              <span class="farbe-divergent"></span>
              Abweichend
            </span>
          </div>
        </div>
        <button class="debug-modal-close" onclick="schliesseDebugDialog()">&times;</button>
      </div>
      <div class="debug-modal-body">
        ${vergleichstabelle}
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // Event-Listener für Klicks auf Tabellenzellen (Event Delegation)
  const tabelle = modal.querySelector(".debug-vergleichstabelle");
  tabelle.addEventListener("click", (e) => {
    const td = e.target.closest("td[data-wert]");
    if (td) {
      const wert = td.getAttribute("data-wert");
      kopiereDebugWert(wert, td);
    }
  });

  // Event-Listener für den CODE-Chip in der Überschrift
  const codeChip = modal.querySelector(".debug-code-chip");
  if (codeChip) {
    codeChip.addEventListener("click", (e) => {
      const wert = e.target.getAttribute("data-wert");
      kopiereDebugWert(wert, e.target);
    });
  }

  // Modal schließen bei Klick außerhalb
  modal.addEventListener("click", (e) => {
    if (e.target === modal) schliesseDebugDialog();
  });

  // ESC-Taste zum Schließen
  document.addEventListener("keydown", function escHandler(e) {
    if (e.key === "Escape") {
      schliesseDebugDialog();
      document.removeEventListener("keydown", escHandler);
    }
  });
};

window.schliesseDebugDialog = function () {
  const modal = document.querySelector(".debug-modal");
  if (modal) modal.remove();
};

window.toggleNormen = function (analytIndex) {
  const normenZeile = document.getElementById(`normen-${analytIndex}`);
  const toggleButton = document.querySelector(
    `[data-analyt-index="${analytIndex}"] .normen-toggle`
  );

  if (normenZeile.style.display === "none") {
    normenZeile.style.display = "table-row";
    toggleButton.innerHTML = toggleButton.innerHTML.replace("📋", "📂");
    toggleButton.title = toggleButton.title.replace("anzeigen", "verbergen");
  } else {
    normenZeile.style.display = "none";
    toggleButton.innerHTML = toggleButton.innerHTML.replace("📂", "📋");
    toggleButton.title = toggleButton.title.replace("verbergen", "anzeigen");
  }
};

function vergleicheNormenArrays(normenArrays) {
  // Wenn ein Array leer ist und andere nicht, sind sie unterschiedlich
  const laengen = normenArrays.map((arr) => arr.length);
  if (!laengen.every((l) => l === laengen[0])) {
    return false;
  }

  // Wenn alle Arrays leer sind, sind sie gleich
  if (laengen[0] === 0) {
    return true;
  }

  // Vergleiche jede Norm-Position in allen Arrays
  for (let i = 0; i < laengen[0]; i++) {
    const normenAnPosition = normenArrays.map((arr) => arr[i]);

    // Vergleiche alle Normen an dieser Position
    const ersteNorm = normenAnPosition[0];
    const alleGleich = normenAnPosition.every(
      (norm) => JSON.stringify(norm) === JSON.stringify(ersteNorm)
    );

    if (!alleGleich) {
      return false;
    }
  }

  return true;
}

window.kopiereDebugWert = async function (wert, element) {
  if (!wert || wert === "-") return;

  await kopiereInZwischenablage(wert);
};

async function kopiereInZwischenablage(text) {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (error) {
      console.warn("Modern-Clipboard-Methode fehlgeschlagen: ", error);
    }
  }

  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0;";
  document.body.appendChild(textArea);
  textArea.select();

  try {
    document.execCommand("copy");
  } catch (error) {
    console.warn("Workaround-Clipboard-Methode fehlgeschlagen: ", error);
  } finally {
    document.body.removeChild(textArea);
  }
}

// ==== Ende Debug Modal Dialog ====
