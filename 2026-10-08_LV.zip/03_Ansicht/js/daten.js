import { erstelleMandant } from "./mandant.js";

window.deploymentEnvironment;
window.globaleAnalytendaten = [];
window.globalesAufbereitungsdatum;

export async function ladeMandantendaten() {
  let res = await fetch(`./config/deployment-config.json`);
  if (!res.ok) throw new Error("Netzwerkfehler: " + res.statusText);
  const config = await res.json();
  window.deploymentEnvironment = config.deployment_environment;

  res = await fetch(`./config/mandant-${config.mandant_key}.json`);
  if (!res.ok) throw new Error("Netzwerkfehler: " + res.statusText);
  const mandantConfig = await res.json();

  res = await fetch(mandantConfig.kopfzeilenlogoPfadUndName);
  let svgText = await res.text();
  mandantConfig.kopfzeilenlogodatenUrl = `data:image/svg+xml,${encodeURIComponent(
    svgText,
  )}`;

  res = await fetch(mandantConfig.dAkkSLogoPfadUndName);
  svgText = await res.text();
  mandantConfig.dAkkSLogodatenUrl = `data:image/svg+xml,${encodeURIComponent(
    svgText,
  )}`;

  erstelleMandant(mandantConfig);
}

export async function ladeAnalytendaten() {
  let dateinamenerweiterung =
    window.deploymentEnvironment === "internal" ? "" : "_ohne_versand";

  const res = await fetch(
    `./aufbereitet/aufbereitung_resultat${dateinamenerweiterung}.json`,
  );
  if (!res.ok) throw new Error("Netzwerkfehler: " + res.statusText);
  return await res.json();
}

export function verarbeiteDaten(json) {
  window.globalesAufbereitungsdatum = json.aufbereitungsdatum;

  window.globaleAnalytendaten = json.analytendaten.sort((a, b) =>
    (a.BESCHREIBUNG || "").localeCompare(b.BESCHREIBUNG || "", "de", {
      sensitivity: "base",
    }),
  );
}
