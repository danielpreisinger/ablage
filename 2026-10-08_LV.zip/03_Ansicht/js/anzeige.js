import { holeMandant } from "./mandant.js";

let ladeStartzeit = 0;
const DESKTOP_BREAKPOINT = 767.99;

let aktuelleNavigation = {
  typ: null,
  zeichen: null,
  suchbegriff: null,
  ausgewaehlterAnalytCode: null,
};

const dom = {
  laderad: document.getElementById("laderad"),
  menuebutton: document.getElementById("menuebutton"),
  kopfzeilenLogoVerlinkung: document.getElementById(
    "kopfzeilenlogo-verlinkung",
  ),
  kopfzeilenLogo: document.getElementById("kopfzeilenlogo"),
  sekundaererMandantenname: document.getElementById(
    "sekundaerer-mandantenname",
  ),
  auswahlmenue: document.getElementById("auswahlmenue"),
  suchfeld: document.getElementById("suchfeld"),
  suchfeldLeerenButton: document.getElementById("suchfeld-leeren-button"),
  suchbutton: document.getElementById("suchbutton"),
  zeichenraster: document.getElementById("zeichenraster"),
  ergebnisbox: document.getElementById("ergebnisbox"),
  auswahlmenueZeigerPfeil: document.getElementById("auswahlmenue-zeiger-pfeil"),
  topHauptinhalt: document.getElementById("top-hauptinhalt"),
  werkzeugbox: document.getElementById("werkzeugbox"),
  kopierlinkbutton: document.getElementById("kopierlinkbutton"),
  druckbutton: document.getElementById("druckbutton"),
  analytbox: document.getElementById("analytbox"),
  jahr: document.getElementById("jahr"),
  primaererMandantenname: document.getElementById("primaerer-mandantenname"),
  impressumUrl: document.getElementById("impressum"),
  stand: document.getElementById("stand"),
  nachObenButton: document.getElementById("nach-oben-button"),
  footer: document.querySelector("footer"),
};

// ==== Mandantenspezifische Anzeige ====

export function initialisiereMandantenspezifischeAnzeige() {
  const mandant = holeMandant();

  const link = document.createElement("link");
  link.rel = "icon";
  link.type = "image/x-icon";
  link.href = `${mandant.holeFaviconPfadUndName()}?v=${ladeStartzeit}`;
  document.head.appendChild(link);

  dom.kopfzeilenLogoVerlinkung.href = mandant.holeKopfzeilenlogoVerlinkungUrl();
  dom.kopfzeilenLogo.src = mandant.holeKopfzeilenlogodatenUrl();
  dom.kopfzeilenLogo.alt = mandant.holeKopfzeilenlogoTitle();
  dom.kopfzeilenLogo.title = mandant.holeKopfzeilenlogoTitle();
  dom.sekundaererMandantenname.textContent =
    mandant.holeSekundaererMandantenname();
  dom.primaererMandantenname.textContent = mandant.holePrimaererMandantenname();
  dom.impressumUrl.href = mandant.holeImpressumUrl();

  document.documentElement.style.setProperty(
    "--primaerfarbe",
    mandant.holePrimaerfarbe(),
  );
  document.documentElement.style.setProperty(
    "--sekundaerfarbe",
    mandant.holeSekundaerfarbe(),
  );
  document.documentElement.style.setProperty(
    "--akzentfarbe",
    mandant.holeAkzentfarbe(),
  );
  document.documentElement.style.setProperty(
    "--akzentfarbe-hintergrund",
    mandant.holeAkzentfarbeHintergrund(),
  );
}

// ==== Grundlegende UI-Elemente ====

export function initialisiereLaderad() {
  ladeStartzeit = Date.now();
}

export function deaktiviereLaderad() {
  const MIN_DAUER = 100;
  const vergangen = Date.now() - ladeStartzeit;
  const verbleibend = Math.max(0, MIN_DAUER - vergangen);

  setTimeout(() => {
    if (!dom.laderad) return;
    dom.laderad.style.opacity = "0";
    dom.laderad.addEventListener("transitionend", () => dom.laderad.remove(), {
      once: true,
    });
  }, verbleibend);
}

function aktualisiereSeitentitel(subtitel = "") {
  const standardTitel = holeMandant().holeStandardTitel();
  document.title = subtitel ? `${subtitel} | ${standardTitel}` : standardTitel;
}

export function initialisiereMenuebutton() {
  behandleMenueAktivStatusBreitenspezifisch();

  dom.menuebutton.addEventListener("click", () => {
    dom.menuebutton.classList.toggle("active");
    dom.auswahlmenue.classList.toggle("active");
    aktualisiereAuswahlmenueZeigerPfeil();
  });

  window.addEventListener("resize", () => {
    behandleMenueAktivStatusBreitenspezifisch();
    aktualisiereAuswahlmenueZeigerPfeil();
  });

  // Initiale Pfeil-Ausrichtung setzen
  aktualisiereAuswahlmenueZeigerPfeil();
}

function behandleMenueAktivStatusBreitenspezifisch() {
  const istDesktop = window.innerWidth >= DESKTOP_BREAKPOINT;

  if (istDesktop) {
    dom.menuebutton.classList.add("active");
    dom.auswahlmenue.classList.add("active");
  } else {
    dom.menuebutton.classList.remove("active");
    dom.auswahlmenue.classList.remove("active");
  }
}

function aktualisiereAuswahlmenueZeigerPfeil() {
  const istDesktop = window.innerWidth >= DESKTOP_BREAKPOINT;
  const istMenueAktiv = dom.menuebutton.classList.contains("active");

  const rotation = istDesktop && istMenueAktiv ? "0deg" : "90deg";
  dom.auswahlmenueZeigerPfeil.style.transform = `rotate(${rotation})`;
}

export function initialisiereNachObenButton() {
  function aktualisiereSichtbarkeitNachObenButton() {
    const istScrollbar =
      dom.analytbox.scrollHeight > dom.analytbox.clientHeight;
    const istGescrollt = dom.analytbox.scrollTop > 1;

    dom.nachObenButton.classList.toggle(
      "visible",
      istScrollbar && istGescrollt,
    );
  }

  dom.analytbox.addEventListener(
    "scroll",
    aktualisiereSichtbarkeitNachObenButton,
  );

  const observer = new MutationObserver(aktualisiereSichtbarkeitNachObenButton);

  observer.observe(dom.analytbox, {
    childList: true,
    subtree: false,
  });

  dom.nachObenButton.addEventListener("click", () => {
    dom.analytbox.scrollTo({ top: 0, behavior: "smooth" });
  });
}

export function initialisiereFooter() {
  dom.jahr.textContent = globalesAufbereitungsdatum.slice(0, 4);

  const isoDateString = globalesAufbereitungsdatum.replace(
    /^(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})$/,
    "$1T$2:$3:$4",
  );
  dom.stand.textContent = new Date(isoDateString).toLocaleString("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

// ==== Suchfunktion ====

export function initialisiereSuche() {
  dom.suchbutton.addEventListener("click", behandleSucheingabe);
  dom.suchfeld.addEventListener("keydown", (event) => {
    if (event.key === "Enter") behandleSucheingabe(event);
  });

  // Clear-Button Funktionalität
  dom.suchfeldLeerenButton.addEventListener("click", leereSuchfeld);
}

function leereSuchfeld() {
  dom.suchfeld.value = "";
  dom.suchfeld.focus();

  // Wenn eine Suche aktiv war, zur Startseite zurückkehren
  const hashParams = new URLSearchParams(window.location.hash.slice(1));
  if (hashParams.get("suche")) {
    window.location.hash = "";
  }
}

function behandleSucheingabe(event) {
  if (event) event.preventDefault();
  const begriff = dom.suchfeld.value.trim();
  if (begriff.length === 0) return;
  window.location.hash = `suche=${encodeURIComponent(begriff)}`;
  verbergeAnalyt();
}

function fuehreSucheAus(suchbegriff, ausgewaehlterAnalytCode = null) {
  if (
    aktuelleNavigation.typ === "suche" &&
    aktuelleNavigation.suchbegriff === suchbegriff &&
    aktuelleNavigation.ausgewaehlterAnalytCode === ausgewaehlterAnalytCode
  ) {
    return;
  }

  aktuelleNavigation.typ = "suche";
  aktuelleNavigation.zeichen = null;
  aktuelleNavigation.suchbegriff = suchbegriff;
  aktuelleNavigation.ausgewaehlterAnalytCode = ausgewaehlterAnalytCode;

  const lowerCase = suchbegriff.toLowerCase();
  const eindeutigeCodes = new Set();

  const treffer = globaleAnalytendaten.filter((a) => {
    const passt =
      a.ist_anforderbar &&
      (a.ANALYTX == suchbegriff ||
        a.CODE.toLowerCase().includes(lowerCase) ||
        a.BESCHREIBUNG.toLowerCase().includes(lowerCase) ||
        a.BEREICH_CODE.toLowerCase().includes(lowerCase) ||
        a.BEREICH_BESCHREIBUNG.toLowerCase().includes(lowerCase) ||
        (a.suchbegriffe || "").toLowerCase().includes(lowerCase));

    if (!passt || eindeutigeCodes.has(a.CODE)) return false;

    eindeutigeCodes.add(a.CODE);
    return true;
  });

  verbergeAnalyt();
  zeigeSuchergebnisse(treffer, suchbegriff, ausgewaehlterAnalytCode);
  aktualisiereSeitentitel("Suche");
}

function zeigeSuchergebnisse(
  treffer,
  suchbegriff,
  ausgewaehlterAnalytCode = null,
) {
  if (treffer.length === 0) {
    dom.ergebnisbox.innerHTML = `<div id="ergebnisse" class="custom-scrollbar active"><h2>Keine Treffer für "${suchbegriff}" gefunden.</h2></div>`;
    return;
  }
  dom.ergebnisbox.innerHTML = `
    <div id="ergebnisse" class="custom-scrollbar active">
      <h2>${treffer.length} Treffer für "${suchbegriff}":</h2>
      <ul>
        ${treffer
          .map(
            (item) =>
              `<li>${erstelleVerlinkung(
                item,
                {
                  suche: suchbegriff,
                },
                item.CODE === ausgewaehlterAnalytCode,
              )}</li>`,
          )
          .join("")}
      </ul>
    </div>
  `;
  verlinkeAnalyteneintraege();
}

// ==== Zeichenraster ====

export function initialisiereZeichenraster() {
  dom.zeichenraster.innerHTML = "";
  const gruppiert = gruppiereAnalytendatenNachZeichen();

  function sortiereNachReihenfolge(key) {
    if (key === "ziffer") return "0";
    if (key === "sonderzeichen") return "1";
    return "2" + key;
  }

  function ermittleButtonLabel(zeichen) {
    if (zeichen === "ziffer") return "0 - 9";
    if (zeichen === "sonderzeichen") return "#";
    return zeichen;
  }

  Object.keys(gruppiert)
    .sort((a, b) =>
      sortiereNachReihenfolge(a).localeCompare(
        sortiereNachReihenfolge(b),
        "de",
        {
          sensitivity: "base",
        },
      ),
    )
    .forEach((zeichen) => {
      const button = document.createElement("button");
      button.textContent = ermittleButtonLabel(zeichen);
      button.className = "zeichenbutton";
      button.dataset.zeichen = zeichen;
      button.title = `Analyten anzeigen, die mit "${ermittleButtonLabel(
        zeichen,
      )}" beginnen`;
      button.addEventListener("click", () =>
        fuehreZeichenauswahlAus(button, zeichen),
      );
      dom.zeichenraster.appendChild(button);
    });
}

function fuehreZeichenauswahlAus(button, zeichen) {
  const aktiv = button.classList.contains("active");
  verbergeAnalyt();
  if (aktiv) {
    dom.ergebnisbox.innerHTML = "";
    window.location.hash = "";
  } else {
    aktiviereZeichenbutton(button);
    window.location.hash = `zeichen=${encodeURIComponent(zeichen)}`;
  }
}

function gruppiereAnalytendatenNachZeichen() {
  const gruppierteAnalytendaten = {};
  const eindeutigeCodes = new Set();

  globaleAnalytendaten.forEach((eintrag) => {
    if (!eintrag.ist_anforderbar) return;

    const z = bestimmeZeichenwert(eintrag.BESCHREIBUNG);

    if (!gruppierteAnalytendaten[z]) gruppierteAnalytendaten[z] = [];

    if (!eindeutigeCodes.has(eintrag.CODE)) {
      gruppierteAnalytendaten[z].push(eintrag);
      eindeutigeCodes.add(eintrag.CODE);
    }
  });

  return gruppierteAnalytendaten;
}

function bestimmeZeichenwert(beschreibung) {
  const key = beschreibung?.trim().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const erstesZeichen = key?.[0]?.toUpperCase();
  if (/^[0-9]$/.test(erstesZeichen)) return "ziffer";
  if (/^[A-Z]$/.test(erstesZeichen)) return erstesZeichen;
  return "sonderzeichen";
}

function zeigeZeichengruppe(zeichen, ausgewaehlterAnalytCode) {
  if (
    aktuelleNavigation.typ === "zeichen" &&
    aktuelleNavigation.zeichen === zeichen &&
    aktuelleNavigation.ausgewaehlterAnalytCode === ausgewaehlterAnalytCode
  ) {
    return;
  }

  aktuelleNavigation.typ = "zeichen";
  aktuelleNavigation.zeichen = zeichen;
  aktuelleNavigation.suchbegriff = null;
  aktuelleNavigation.ausgewaehlterAnalytCode = ausgewaehlterAnalytCode;

  const eintraege = gruppiereAnalytendatenNachZeichen()[zeichen] || [];

  let kriterium = zeichen[0].toUpperCase() + zeichen.slice(1);
  if (/^[A-Z]$/.test(zeichen)) kriterium = zeichen;
  const ergebnistitel = `Analyten beginnend mit ${kriterium}:`;

  dom.ergebnisbox.innerHTML = `
    <div id="ergebnisse" class="custom-scrollbar active">
      <h2>${ergebnistitel}</h2>
      <ul>
        ${eintraege
          .map(
            (item) =>
              `<li>${erstelleVerlinkung(
                item,
                { zeichen: zeichen },
                item.CODE === ausgewaehlterAnalytCode,
              )}</li>`,
          )
          .join("")}
      </ul>
    </div>
  `;
  verlinkeAnalyteneintraege();
  aktualisiereSeitentitel(kriterium);
}

function aktiviereZeichenbutton(button) {
  button.classList.add("active");
}

function deaktiviereAlleZeichenbuttons() {
  dom.zeichenraster
    .querySelectorAll(".zeichenbutton")
    .forEach((btn) => btn.classList.remove("active"));
}

function firstNonEmptyString(...values) {
  return (
    values.find((v) => typeof v === "string" && v.trim().length > 0)?.trim() ??
    "-"
  );
}

// ==== Ergebnisbox ====

export function initialisiereDynamischeSeitenhoehe() {
  const ABSTAND_PUFFER = 16; // Entspricht ungefähr --abstand-standard in style.css
  const MINDEST_ERGEBNISHOEHE = 150;

  let rafId = null;

  function setzeHoehenFuerMobileZurueck() {
    const ergebnisliste = dom.ergebnisbox.querySelector("#ergebnisse ul");
    if (ergebnisliste) {
      ergebnisliste.style.height = "";
      ergebnisliste.style.overflowY = "";
    }
    dom.analytbox.style.maxHeight = "";
    dom.analytbox.style.overflowY = "";
  }

  function setzeErgebnislisteHoehe() {
    const ergebnisliste = dom.ergebnisbox.querySelector("#ergebnisse ul");
    if (!ergebnisliste) return;

    const ergebnislisteRect = ergebnisliste.getBoundingClientRect();
    const footer = document.querySelector("footer");
    const footerHoehe = footer ? footer.getBoundingClientRect().height : 0;

    const verfuegbarerPlatz =
      window.innerHeight - ergebnislisteRect.top - footerHoehe - ABSTAND_PUFFER;

    const endgueltigeHoehe = Math.max(MINDEST_ERGEBNISHOEHE, verfuegbarerPlatz);

    ergebnisliste.style.height = `${endgueltigeHoehe}px`;
    ergebnisliste.style.overflowY = "auto";
  }

  function setzeAnalytboxHoehe() {
    if (!dom.analytbox.classList.contains("active")) return;

    const auswahlmenueHoehe = dom.auswahlmenue.getBoundingClientRect().height;
    const topHauptinhaltHoehe =
      dom.topHauptinhalt.getBoundingClientRect().height || 0;

    const maxAnalytboxHoehe =
      auswahlmenueHoehe - topHauptinhaltHoehe - ABSTAND_PUFFER;

    dom.analytbox.style.maxHeight = `${maxAnalytboxHoehe}px`;
    dom.analytbox.style.overflowY = "auto";
  }

  function berechneUndSetzeErgebnishoehe() {
    if (rafId) cancelAnimationFrame(rafId);

    rafId = requestAnimationFrame(() => {
      rafId = null;

      if (window.innerWidth < DESKTOP_BREAKPOINT) {
        setzeHoehenFuerMobileZurueck();
        return;
      }

      setzeErgebnislisteHoehe();
      setzeAnalytboxHoehe();
    });
  }

  berechneUndSetzeErgebnishoehe();

  window.addEventListener("resize", berechneUndSetzeErgebnishoehe, {
    passive: true,
  });

  const observer = new MutationObserver(() => {
    setTimeout(berechneUndSetzeErgebnishoehe, 10);
  });

  observer.observe(dom.ergebnisbox, {
    childList: true,
    subtree: true,
  });

  const analytboxObserver = new MutationObserver(() => {
    setTimeout(berechneUndSetzeErgebnishoehe, 10);
  });

  analytboxObserver.observe(dom.analytbox, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class"],
  });

  return () => {
    window.removeEventListener("resize", berechneUndSetzeErgebnishoehe);
    observer.disconnect();
    analytboxObserver.disconnect();
    if (rafId) cancelAnimationFrame(rafId);
  };
}

// ==== Werkzeugbox ====

export function initialisiereWerkzeugbox() {
  dom.kopierlinkbutton.addEventListener("click", async () => {
    await kopiereInZwischenablage(window.location.href);
    setTimeout(() => dom.kopierlinkbutton.blur(), 500);
  });

  dom.druckbutton.addEventListener("click", () => {
    dom.druckbutton.focus();
    setTimeout(() => {
      window.print();
      dom.druckbutton.blur();
    }, 500);
  });
}

async function kopiereInZwischenablage(text) {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (error) {
      console.warn("Modern-Clipboard-Methode fehlgeschlagen: ", error);
    }
  }

  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.cssText = "position:fixed;left:-9999px;top:-9999px;opacity:0;";
  document.body.appendChild(textArea);
  textArea.select();

  try {
    document.execCommand("copy");
  } catch (error) {
    console.warn("Workaround-Clipboard-Methode fehlgeschlagen: ", error);
  } finally {
    document.body.removeChild(textArea);
  }
}

// ==== Analytanzeige ====

async function zeigeAnalyt(analytCode) {
  const gefundeneAnalyten = globaleAnalytendaten.filter(
    (a) => a.CODE === analytCode,
  );
  let analyt = gefundeneAnalyten[0];
  const mandant = holeMandant();
  const dAkkSPdfUrl = mandant.holeDAkkSPdfUrl();
  const dAkkSLogodatenUrl = mandant.holeDAkkSLogodatenUrl();

  const dakksLogodatenUrlMitPdfUrl = analyt.ist_akkreditiert
    ? `
    <a href="${dAkkSPdfUrl}" class="externerlink" target="_blank" title="DAkkS-Akkreditierungsurkunde öffnen (PDF)">
      <img
        src="${dAkkSLogodatenUrl}"
        alt="Logo der DAkkS-Akkreditierungsstelle"
        id="dakks-logo"
      />
    </a>
  `
    : "";

  let html = `
    <div class="titel-mit-akkreditierungslogo">
      <h2>${analyt.BESCHREIBUNG ?? ""}</h2>
      ${dakksLogodatenUrlMitPdfUrl}
    </div>
    ${zeigeAnalytwerte(analyt, gefundeneAnalyten, dAkkSPdfUrl)}
    ${zeigeNormwerte(analyt.normen)}
  `;

  html += globaleAnalytendaten
    .filter(
      (a) =>
        a.KATEGORISIERUNG_CODE === "LV-Gruppen" &&
        a.BEREICH_CODE === analyt.CODE,
    )
    .map((gruppenAnalyt) => {
      return `
          <div class="titel-ohne-akkreditierungslogo">
            <h3>${gruppenAnalyt.BESCHREIBUNG ?? ""}</h3>
          </div>
          ${zeigeAnalytwerte(gruppenAnalyt, gefundeneAnalyten, dAkkSPdfUrl)}
          ${zeigeNormwerte(gruppenAnalyt.normen)}
        `;
    })
    .join("");

  dom.analytbox.innerHTML = html;
  dom.kopierlinkbutton.classList.add("active");
  dom.druckbutton.classList.add("active");
  dom.analytbox.classList.add("active");

  if (window.innerWidth < DESKTOP_BREAKPOINT) {
    dom.analytbox.scrollIntoView({ behavior: "smooth" });
  } else {
    dom.analytbox.scrollTop = 0;
  }

  aktualisiereSeitentitel(analyt.BESCHREIBUNG);
}

function zeigeAnalytwerte(analyt, gefundeneAnalyten, dAkkSPdfUrl) {
  const bereichslabels = gefundeneAnalyten
    .reduce((eindeutigeBereiche, a) => {
      if (
        !eindeutigeBereiche.some(
          (b) => b.BEREICH_BESCHREIBUNG === a.BEREICH_BESCHREIBUNG,
        )
      ) {
        eindeutigeBereiche.push(a);
      }
      return eindeutigeBereiche;
    }, [])
    .map((a) => {
      return `<span class="bereichslabel" title="${a.BEREICH_BESCHREIBUNG}">${a.BEREICH_BESCHREIBUNG}</span>`;
    })
    .join("");

  const formularlabels = gefundeneAnalyten
    .reduce((eindeutigeFormulare, a) => {
      if (!eindeutigeFormulare.some((b) => b.FORMULARNAME === a.FORMULARNAME)) {
        eindeutigeFormulare.push(a);
      }
      return eindeutigeFormulare;
    }, [])
    .map((a) => {
      return `<span class="formularlabel" title="${a.FORMULARNAME}">${a.FORMULARNAME}</span>`;
    })
    .join("");

  const analytentabellezeilen = [
    [
      gefundeneAnalyten.length === 1 ? "Bereich" : "In Bereichen",
      bereichslabels,
    ],
    [gefundeneAnalyten.length === 1 ? "Bogen" : "In Bögen", formularlabels],
    ["Materialname", analyt.MATERIALNAME ?? "-"],
    ["Verfahren", firstNonEmptyString(analyt.TEXTFELD1, analyt.VERFAHREN)],
    ["Einheit", analyt.UNIT?.trim() ? analyt.UNIT : "-"],
    [
      "Akkreditiert",
      analyt.ist_akkreditiert
        ? `<a class="externerlink" href="${dAkkSPdfUrl}" target="_blank" title="DAkkS-Akkreditierungsurkunde öffnen (PDF)">Ja</a>`
        : "Nein",
    ],
  ].filter(Boolean);

  analytentabellezeilen.push(["Präanalytik", zeigePraeAnalytik(analyt)]);

  // TODO: Debug-Pixel entfernen, sobald nicht mehr notwendig!
  return `
    <div id="analytwertebox">
      <table id="analytwertetabelle" role="table" aria-label="Analytinformationen und technische Details">
        <tbody>
          ${analytentabellezeilen
            .map(
              ([label, value]) => `
            <tr>
              <td>${label}</td>
              <td>${value}</td>
            </tr>`,
            )
            .join("")}
        </tbody>
      </table>
      <button 
        type="button" 
        class="debug-trigger" 
        onclick="zeigeDebugDialog('${analyt.CODE}'); this.blur();"
        aria-label="Debug-Informationen"
      ></button>
    </div>
  `;
}

function zeigePraeAnalytik(analyt) {
  const praeAnfAnalytik = analyt.praeanalytikAnf ?? null;
  if (!praeAnfAnalytik) return "keine Angabe";

  const parts = [];

  function getPraeTooltip(key) {
    if (key === "eilt") return "schnellstmöglich einsenden";
    if (key === "gekuehlt")
      return "gekühlt transportieren und bei 2–8 °C lagern";
    if (key === "lichtgeschuetzt") return "vor direktem Licht schützen";
    return key;
  }

  const checkmarkIcon = `<svg class="prae-flag-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path d="M20.7 6.3a1 1 0 0 0-1.4-1.4L9 15.2 4.7 11a1 1 0 0 0-1.4 1.4l5 5a1 1 0 0 0 1.4 0l11-11z" fill="currentColor"/></svg>`;

  Object.keys(praeAnfAnalytik || {}).forEach((k) => {
    const v = praeAnfAnalytik[k];
    if (v === true) {
      const title = getPraeTooltip(k);
      const titleAttr = title ? ` title="${title}"` : "";
      parts.push(
        `<div class="prae-item"${titleAttr}><span class="prae-flag" aria-hidden="true">` +
          checkmarkIcon +
          `</span><span class="prae-label">${k}</span></div>`,
      );
    }
  });

  if (parts.length === 0) return "keine Angabe";

  return `<div class="praeanalytik">${parts.join("")}</div>`;
}

function zeigeNormwerte(normen) {
  let normwertetabelle = "";

  if (normen.length > 0) {
    normwertetabelle = `
      <div id="normwertebox">
        <table id="normwertetabelle" aria-label="Normwerte nach Alter und Geschlecht">
          <thead>
            <tr>
              <th class="rechtsbuendig" title="Mindestalter">Alter von</th>
              <th class="rechtsbuendig" title="Höchstalter">Alter bis</th>
              <th title="Geschlecht (b = beide, w = weiblich, m = männlich)">Geschlecht</th>
              <th title="Unterer Grenzwert anhand Einheit">Norm von</th>
              <th title="Oberer Grenzwert anhand Einheit">Norm bis</th>
            </tr>
          </thead>
          <tbody>
            ${normen
              .map(
                (n) => `
              <tr>
                <td class="rechtsbuendig">${n.ALTERVON} ${n.ZEITEINHEIT}</td>
                <td class="rechtsbuendig">${n.ALTERBIS} ${n.ZEITEINHEIT}</td>
                <td class="mittig">${n.GESCHLECHT ?? "nicht spezifiziert"}</td>
                <td class="rechtsbuendig">${n.NORMVON ?? "-"}</td>
                <td class="rechtsbuendig">${n.NORMBIS ?? "-"}</td>
              </tr>`,
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;
  } else {
    normwertetabelle = `<p>Keine Normwerte vorhanden</p>`;
  }
  return normwertetabelle;
}

function verbergeAnalyt() {
  dom.kopierlinkbutton.classList.remove("active");
  dom.druckbutton.classList.remove("active");
  dom.analytbox.innerHTML = "";
  dom.analytbox.classList.remove("active");
}

// ==== Verlinkung & Hash-Handling ====

function erstelleVerlinkung(
  analyt,
  parameter = {}, // { zeichen, suche : wert}
  active = false,
) {
  const { zeichen, suche } = parameter;
  const params = new URLSearchParams();
  params.set("analyt", analyt.CODE);
  if (zeichen) params.set("zeichen", zeichen);
  if (suche) params.set("suche", suche);

  const cssClass = active ? ' class="active"' : "";

  const vollstaendigerText = [
    analyt.BESCHREIBUNG,
    analyt.MATERIALNAME && `im ${analyt.MATERIALNAME}`,
    analyt.UNIT && `in ${analyt.UNIT}`,
  ]
    .filter(Boolean)
    .join(" ");

  const title = ` title="${vollstaendigerText}"`;

  const materialherkunftstext = analyt.MATERIALNAME
    ? `<span class="begleittext"> im </span><span class="materialherkunftstext">${analyt.MATERIALNAME}</span>`
    : "";
  const einheitenbezugstext = analyt.UNIT
    ? `<span class="begleittext"> in </span><span class="einheitenbezugstext">${analyt.UNIT}</span>`
    : "";

  const aText = `${analyt.BESCHREIBUNG}${materialherkunftstext}${einheitenbezugstext}`;
  return `<a href="#${params.toString()}"${cssClass}${title}>${aText}</a>`;
}

function verlinkeAnalyteneintraege() {
  const ergebnisListe = dom.ergebnisbox.querySelector("#ergebnisse ul");
  if (!ergebnisListe) return;

  const alleLinks = ergebnisListe.querySelectorAll("a");

  alleLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      alleLinks.forEach((el) => el.classList.remove("active"));
      link.classList.add("active");
      window.location.hash = link.hash;
    });
  });
}

export function beobachteHashAenderung() {
  // für initialen Einsprung beim Laden der Seite
  behandleHashAenderung();
  // für jede weitere Navigation innerhalb der SPA
  window.addEventListener("hashchange", behandleHashAenderung);
}

function behandleHashAenderung() {
  const wertNachHashZeichen = window.location.hash.slice(1);
  const hashParams = new URLSearchParams(wertNachHashZeichen);

  const suchbegriff = hashParams.get("suche");
  const zeichenwert = hashParams.get("zeichen");
  const analytCode = hashParams.get("analyt");

  if (suchbegriff && zeichenwert) {
    return zuruecksetzenUndLeeren();
  }

  if (suchbegriff) return behandleSuche(suchbegriff, analytCode);
  if (zeichenwert) return behandleZeichen(zeichenwert, analytCode);
  if (analytCode) return behandleAnalyt(analytCode);

  return zuruecksetzenUndLeeren();

  function behandleSuche(suchbegriff, analytCode) {
    dom.suchfeld.value = suchbegriff;

    const nurAnalytGeaendert =
      aktuelleNavigation.typ === "suche" &&
      aktuelleNavigation.suchbegriff === suchbegriff &&
      aktuelleNavigation.ausgewaehlterAnalytCode !== analytCode;

    if (nurAnalytGeaendert) {
      aktualisiereAktivenLink(analytCode);
      aktuelleNavigation.ausgewaehlterAnalytCode = analytCode;
    } else {
      fuehreSucheAus(suchbegriff, analytCode);
    }

    deaktiviereAlleZeichenbuttons();
    verbergeAnalyt();
    if (analytCode) zeigeAnalyt(analytCode);
  }

  function behandleZeichen(zeichenwert, analytCode) {
    const zeichen = ermittleZeichenwert(zeichenwert);
    const gruppiert = gruppiereAnalytendatenNachZeichen();

    if (!gruppiert[zeichen]) {
      zuruecksetzenUndLeeren();
      return;
    }

    dom.suchfeld.value = "";

    const nurAnalytGeaendert =
      aktuelleNavigation.typ === "zeichen" &&
      aktuelleNavigation.zeichen === zeichen &&
      aktuelleNavigation.ausgewaehlterAnalytCode !== analytCode;

    if (nurAnalytGeaendert) {
      aktualisiereAktivenLink(analytCode);
      aktuelleNavigation.ausgewaehlterAnalytCode = analytCode;
    } else {
      deaktiviereAlleZeichenbuttons();
      zeigeZeichengruppe(zeichen, analytCode);
    }

    verbergeAnalyt();

    const button = document.querySelector(
      `.zeichenbutton[data-zeichen="${zeichen}"]`,
    );
    if (button) aktiviereZeichenbutton(button);
    if (analytCode) zeigeAnalyt(analytCode);

    function ermittleZeichenwert(zeichenwert) {
      const lowerZeichenwert = zeichenwert.toLowerCase();
      if (lowerZeichenwert === "ziffer" || lowerZeichenwert === "sonderzeichen")
        return lowerZeichenwert;
      return zeichenwert[0].toUpperCase();
    }
  }

  function behandleAnalyt(analytCode) {
    const analyt = globaleAnalytendaten.filter((a) => a.CODE === analytCode);
    const eindeutigerBereichCode =
      analyt.length === 1 ? analyt[0].BEREICH_CODE : null;
    dom.suchfeld.value = "";

    zeigeAnalyt(analytCode, eindeutigerBereichCode);
  }

  function zuruecksetzenUndLeeren() {
    window.location.hash = "";
    dom.suchfeld.value = "";
    deaktiviereAlleZeichenbuttons();
    dom.ergebnisbox.innerHTML = "";
    verbergeAnalyt();
    aktualisiereSeitentitel();

    aktuelleNavigation = {
      typ: null,
      zeichen: null,
      suchbegriff: null,
      ausgewaehlterAnalytCode: null,
    };
  }
}

function aktualisiereAktivenLink(analytCode) {
  dom.ergebnisbox
    .querySelectorAll("#ergebnisse a")
    .forEach((link) => link.classList.remove("active"));

  if (analytCode) {
    const targetLink = dom.ergebnisbox.querySelector(
      `#ergebnisse a[href*="analyt=${encodeURIComponent(analytCode)}"]`,
    );
    targetLink?.classList.add("active");
  }
}
