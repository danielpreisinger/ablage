let mandantInstance = null;

export function erstelleMandant(mandantConfig) {
  if (mandantInstance === null) mandantInstance = new Mandant(mandantConfig);
}

export function holeMandant() {
  return mandantInstance;
}

class Mandant {
  constructor({
    faviconPfadUndName,
    standardTitel,
    kopfzeilenlogoVerlinkungUrl,
    kopfzeilenlogoPfadUndName,
    kopfzeilenlogodatenUrl,
    kopfzeilenlogoTitle,
    sekundaererMandantenname,
    dAkkSLogoPfadUndName,
    dAkkSLogodatenUrl,
    dAkkSPdfUrl,
    primaererMandantenname,
    impressumUrl,
    primaerfarbe,
    sekundaerfarbe,
    akzentfarbe,
    akzentfarbeHintergrund,
  }) {
    this.faviconPfadUndName = faviconPfadUndName;
    this.standardTitel = standardTitel;
    this.kopfzeilenlogoVerlinkungUrl = kopfzeilenlogoVerlinkungUrl;
    this.kopfzeilenlogoPfadUndName = kopfzeilenlogoPfadUndName;
    this.kopfzeilenlogodatenUrl = kopfzeilenlogodatenUrl;
    this.kopfzeilenlogoTitle = kopfzeilenlogoTitle;
    this.sekundaererMandantenname = sekundaererMandantenname;
    this.dAkkSLogoPfadUndName = dAkkSLogoPfadUndName;
    this.dAkkSLogodatenUrl = dAkkSLogodatenUrl;
    this.dAkkSPdfUrl = dAkkSPdfUrl;
    this.primaererMandantenname = primaererMandantenname;
    this.impressumUrl = impressumUrl;
    this.primaerfarbe = primaerfarbe;
    this.sekundaerfarbe = sekundaerfarbe;
    this.akzentfarbe = akzentfarbe;
    this.akzentfarbeHintergrund = akzentfarbeHintergrund;
  }

  holeFaviconPfadUndName() {
    return this.faviconPfadUndName;
  }
  holeStandardTitel() {
    return this.standardTitel;
  }
  holeKopfzeilenlogoVerlinkungUrl() {
    return this.kopfzeilenlogoVerlinkungUrl;
  }
  holeKopfzeilenlogoPfadUndName() {
    return this.kopfzeilenlogoPfadUndName;
  }
  holeKopfzeilenlogodatenUrl() {
    return this.kopfzeilenlogodatenUrl;
  }
  holeKopfzeilenlogoTitle() {
    return this.kopfzeilenlogoTitle;
  }
  holeSekundaererMandantenname() {
    return this.sekundaererMandantenname;
  }
  holeDAkkSLogopfadUndName() {
    return this.dAkkSLogoPfadUndName;
  }
  holeDAkkSLogodatenUrl() {
    return this.dAkkSLogodatenUrl;
  }
  holeDAkkSPdfUrl() {
    return this.dAkkSPdfUrl;
  }
  holePrimaererMandantenname() {
    return this.primaererMandantenname;
  }
  holeImpressumUrl() {
    return this.impressumUrl;
  }
  holePrimaerfarbe() {
    return this.primaerfarbe;
  }
  holeSekundaerfarbe() {
    return this.sekundaerfarbe;
  }
  holeAkzentfarbe() {
    return this.akzentfarbe;
  }
  holeAkzentfarbeHintergrund() {
    return this.akzentfarbeHintergrund;
  }
}
